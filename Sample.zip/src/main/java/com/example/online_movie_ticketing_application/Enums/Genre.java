package com.example.online_movie_ticketing_application.Enums;

public enum Genre {
    FICTIONAL,
    COMEDY,
    ACTION,
    HORROR,
    SCIENCE_FICTION,
    DRAMA,
    ROMANCE,
    ADVENTURE,
    FANTASY,
    CRIME,
    ANIMATION,
    WAR,
    SCI_FI
}
