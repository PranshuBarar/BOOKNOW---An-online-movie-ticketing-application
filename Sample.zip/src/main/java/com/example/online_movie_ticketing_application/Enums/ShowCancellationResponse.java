package com.example.online_movie_ticketing_application.Enums;

public enum ShowCancellationResponse {
    SHOW_IS_CANCELED_SUCCESSFULLY,
    SHOW_IS_ALREADY_OVER,
    SHOW_NOT_FOUND
}
