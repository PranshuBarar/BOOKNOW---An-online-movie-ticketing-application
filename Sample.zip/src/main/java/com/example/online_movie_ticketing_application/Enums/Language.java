package com.example.online_movie_ticketing_application.Enums;

public enum Language {
    HINDI,
    ENGLISH,
    TAMIL,
    TELUGU
}
