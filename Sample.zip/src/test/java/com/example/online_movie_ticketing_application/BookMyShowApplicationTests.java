package com.example.online_movie_ticketing_application;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@SpringBootTest
class BookMyShowApplicationTests {
	@Test
	@Disabled
	void contextLoads() {
	}
}
